import matplotlib.pyplot as plt
import numpy as np

def extract_intron_lengths_from_txt(filepath):
    try:
        with open(filepath, "r") as file:
            intron_lengths = [int(line.strip()) for line in file if line.strip().isdigit()]
        
        intron_lengths = [length for length in intron_lengths if length > 10]
        
        return intron_lengths
    except Exception as e:
        print(f"Error reading {filepath}: {e}")
        return []

def plot_intron_trend_lines(filenames, species_names, output_file):
    plt.figure(figsize=(14, 7))
    
    # List of myxozoan species (for red color, except Kudoa species)
    myxozoans = [
        "Myxobolus honghuensis",
        "Myxobolus rasmusseni", 
        "Thelohanellus kitauei",
        "Henneguya salminicola"
    ]
    
    # Kudoa species (for yellow color)
    kudoa_species = [
        "Kudoa neothunni",
        "Kudoa sp trachurus"
    ]
    
    # Number of bins 
    num_bins = 120
    
    # Separate species into four groups for legend ordering
    blue_species = []
    red_species = []
    yellow_species = []
    green_species = []
    
    for i, file in enumerate(filenames):
        intron_lengths = extract_intron_lengths_from_txt(file)
        if not intron_lengths:
            print(f"Warning: No intron lengths found in {file}. Skipping.")
            continue
            
        print(f"Processing {species_names[i]}: {len(intron_lengths)} introns found")  # Debug info
            
        log_lengths = np.log10(intron_lengths)
        
        # Compute histogram
        counts, bin_edges = np.histogram(log_lengths, bins=num_bins)
        bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2
        
        # Choose color based on species
        species_name = species_names[i]
        if "dicyema japonicum" in species_name.lower():
            color = "#228B22"  # Forest green - colorblind friendly
            green_species.append((bin_centers, counts, species_name))
        elif any(kudoa.lower() in species_name.lower() for kudoa in kudoa_species):
            color = "#FF8C00"  # Dark orange for Kudoa species - colorblind friendly
            yellow_species.append((bin_centers, counts, species_name))
        elif any(myxozoan.lower() in species_name.lower() for myxozoan in myxozoans):
            color = "red"  # Red for other myxozoans
            red_species.append((bin_centers, counts, species_name))
        else:
            color = "blue"  # Blue for all other species
            blue_species.append((bin_centers, counts, species_name))
    
    # Plot blue species first (will appear at top of legend)
    for bin_centers, counts, species_name in blue_species:
        plt.plot(
            bin_centers,
            counts,
            label=f"{species_name}",
            color="blue",
            linewidth=2.5
        )
    
    # Plot green species second (Dicyema japonicum - will appear above myxozoans)
    for bin_centers, counts, species_name in green_species:
        plt.plot(
            bin_centers,
            counts,
            label=f"{species_name}",
            color="#228B22",  # Forest green
            linewidth=3.0  # Slightly thicker line to make it stand out more
        )
    
    # Plot yellow species third (Kudoa species - will appear above other myxozoans)
    for bin_centers, counts, species_name in yellow_species:
        plt.plot(
            bin_centers,
            counts,
            label=f"{species_name}",
            color="#FF8C00",  # Dark orange - colorblind friendly
            linewidth=2.5
        )
    
    # Plot red species last (other myxozoans - will appear at bottom of legend)
    for bin_centers, counts, species_name in red_species:
        plt.plot(
            bin_centers,
            counts,
            label=f"{species_name}",
            color="red",
            linewidth=2.5
        )
    
    plt.title("Intron Length Distribution Across Species (Log Scale)", fontsize=16)
    plt.xlabel("Intron Length (log10 scale)", fontsize=14)
    plt.ylabel("Number of Introns", fontsize=14)
    
    # Increased legend font size from 6 to 8
    plt.legend(title="Species", fontsize=8, loc='best')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_file, dpi=300)
    plt.close()

if __name__ == "__main__":
    filenames = [
        "/dorotheeh/hadjez/Homo_sapiens_lengths.txt",
        "/dorotheeh/hadjez/Oikopleura_dioica_lengths.txt",
        "/dorotheeh/hadjez/Ciona_intestinalis_lengths.txt",
        "/dorotheeh/hadjez/Lytechinus_variegatus_lengths.txt",
        "/dorotheeh/hadjez/Drosophila_melanogaster_lengths.txt",
        "/dorotheeh/hadjez/Euroglyphus_maynei_lengths.txt",
        "/dorotheeh/hadjez/Mesodorylaimus_lengths.txt",
        "/dorotheeh/hadjez/ptycholaimellus_sp_lengths.txt",
        "/dorotheeh/hadjez/Caenorhabditis_elegans_lengths.txt",
        "/dorotheeh/hadjez/Meloidogyne_graminicola_lengths.txt",
        "/dorotheeh/hadjez/Strongyloides_ratti_lengths.txt",
        "/dorotheeh/hadjez/dicyema_japonicom_lengths.txt",
        "/dorotheeh/hadjez/Intoshia_linei_lengths.txt",
        "/dorotheeh/hadjez/Echinococcus_granulosus_lengths.txt",
        "/dorotheeh/hadjez/Schistosoma_mansoni_lengths.txt",
        "/dorotheeh/hadjez/Adineta_vaga_lengths.txt",
        "/dorotheeh/hadjez/Helobdella_robusta_lengths.txt",
        "/dorotheeh/hadjez/Nematostella_lengths.txt",
        "/dorotheeh/hadjez/Hydra_vulgaris_lengths.txt",
        "/dorotheeh/hadjez/Myxobollus_honghuensis_lengths.txt",
        "/dorotheeh/hadjez/Myxobolus_rasmusseni_lengths.txt",
        "/dorotheeh/hadjez/Kudoa_neothunni_lengths.txt",
        "/dorotheeh/hadjez/Thelohanellus_kitauei_lengths.txt",
        "/dorotheeh/hadjez/Kudoa_sp_trachurus_lengths.txt",
        "/dorotheeh/hadjez/Henneguya_salminicola_lengths.txt",
        "/dorotheeh/hadjez/Oscarella_lobularis_lengths.txt",
        "/dorotheeh/hadjez/Halichondria_panicea_lengths.txt",
        "/dorotheeh/hadjez/Pomacea_canaliculata_lengths.txt"
    ]
    species_names = [
        "Homo sapiens",
        "Oikopleura dioica",
        "Ciona intestinalis",
        "Lytechinus variegatus",
        "Drosophila melanogaster",
        "Euroglyphus maynei",
        "Mesodorylaimus sp",
        "Ptycholaimellus sp",
        "Caenorhabditis elegans",
        "Meloidogyne graminicola",
        "Strongyloides ratti",
        "Dicyema japonicum",
        "Intoshia linei",
        "Echinococcus granulosus",
        "Schistosoma mansoni",
        "Adineta vaga",
        "Helobdella robusta",
        "Nematostella vectensis",
        "Hydra vulgaris",
        "Myxobolus honghuensis",
        "Myxobolus rasmusseni",
        "Kudoa neothunni",
        "Thelohanellus kitauei",
        "Kudoa sp trachurus",
        "Henneguya salminicola",
        "Oscarella lobularis",
        "Halichondria panicea",
        "Pomacea canaliculata"
    ]
    
    output_file = "/dorotheeh/hadjez/RB_Intron_histogram_for_paper.png"
    plot_intron_trend_lines(filenames, species_names, output_file)
    