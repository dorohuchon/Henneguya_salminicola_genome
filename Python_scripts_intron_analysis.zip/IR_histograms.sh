#!/bin/bash
#SBATCH --job-name=IR_hist
#SBATCH --partition=power-huchond 
#SBATCH --cpus-per-task=20
#SBATCH --mem-per-cpu=6G       
#SBATCH --output=IR_hist.out
#SBATCH --error=IR_hist.err

module load mamba-env158/python3.13

python /dorotheeh/hadjez/IR_FIX.py "Henneguya salminicola" /dorotheeh/hadjez/uniq_exons_per_gene_HSA.csv /dorotheeh/hadjez/ir_transcripts_hsa.csv "Nematostella vectensis" /dorotheeh/hadjez/uniq_exons_per_gene_nemato_male.csv /dorotheeh/hadjez/ir_transcripts_nemato_male.csv "Hydra vulgaris" /dorotheeh/hadjez/uniq_exons_per_gene_hydra.csv /dorotheeh/hadjez/ir_transcripts_hydra.csv

