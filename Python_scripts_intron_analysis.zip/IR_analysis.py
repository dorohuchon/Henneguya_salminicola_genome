import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sys

def analyze_species(exons_file, ir_file, species_name):
    # Read files
    exons_df = pd.read_csv(exons_file)  # Column names are gene_id, num_uniq_exon
    ir_df = pd.read_csv(ir_file)        # Column name is er_transcript_ids

    # Clean up IDs
    exons_df['gene_id'] = exons_df['gene_id'].astype(str).str.strip()
    ir_df['er_transcript_ids'] = ir_df['er_transcript_ids'].astype(str).str.strip()

    # Extract gene ID from transcript ID
    ir_df['gene_id'] = ir_df['er_transcript_ids'].apply(
        lambda x: ".".join(x.split(".")[:2])
    )

    exon_gene_ids = set(exons_df['gene_id'])
    ir_gene_ids = set(ir_df['gene_id'])
    print(f"[{species_name}] Total genes in exon file: {len(exon_gene_ids)}")
    print(f"[{species_name}] Total genes in IR file: {len(ir_gene_ids)}")
    print(f"[{species_name}] Genes in both: {len(exon_gene_ids & ir_gene_ids)}")
    print(f"[{species_name}] Genes with IR but missing from exon file: {len(ir_gene_ids - exon_gene_ids)}")

    # Count IR per gene
    ir_counts_per_gene = ir_df['gene_id'].value_counts().to_dict()

    # Build breakdown
    exon_breakdown = {}
    for _, row in exons_df.iterrows():
        gene_id = row['gene_id']
        num_exons = row['num_uniq_exon']
        ir_events = ir_counts_per_gene.get(gene_id, 0)

        if num_exons not in exon_breakdown:
            exon_breakdown[num_exons] = {'total_genes': 0, 'genes_with_ir': 0}
        exon_breakdown[num_exons]['total_genes'] += 1
        if ir_events > 0:
            exon_breakdown[num_exons]['genes_with_ir'] += 1

    # Print breakdown table
    print(f"\nBreakdown for {species_name}:")
    for exon_count in sorted(exon_breakdown.keys()):
        total = exon_breakdown[exon_count]['total_genes']
        with_ir = exon_breakdown[exon_count]['genes_with_ir']
        print(f"  Exons: {exon_count} | Total genes: {total} | Genes with IR: {with_ir}")

    return {'species': species_name, 'exon_breakdown': exon_breakdown}

def plot_ir_events_by_exon_count(species_data_list):
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c']
    all_exon_counts = sorted(set().union(*[s['exon_breakdown'].keys() for s in species_data_list]))
    all_exon_counts = [i for i in all_exon_counts if 0 < i <= 20]

    plt.figure(figsize=(12, 8))
    bar_width = 0.25
    for i, species_data in enumerate(species_data_list):
        species_name = species_data['species']
        breakdown = species_data['exon_breakdown']

        ir_percentages = []
        for exon_count in all_exon_counts:
            if exon_count in breakdown:
                total = breakdown[exon_count]['total_genes']
                with_ir = breakdown[exon_count]['genes_with_ir']
                percentage = (with_ir / total) * 100 if total > 0 else 0
                ir_percentages.append(percentage)
            else:
                ir_percentages.append(0)

        x = np.arange(len(all_exon_counts)) + i * bar_width
        plt.bar(x, ir_percentages, width=bar_width, label=species_name,
                color=colors[i % len(colors)], alpha=0.8, edgecolor='black', linewidth=0.5)

    plt.xlabel("Number of Unique Exons")
    plt.ylabel("Percentage of Genes with IR")
    plt.title("Percentage of Genes with IR by Number of Unique Exons")
    plt.xticks(np.arange(len(all_exon_counts)) + bar_width, all_exon_counts)
    plt.legend()
    plt.grid(axis='y', alpha=0.3)
    plt.tight_layout()
    plt.savefig('ir_percentage_by_unique_exons.png', dpi=300, bbox_inches='tight')
    plt.close()

if __name__ == "__main__":
    if len(sys.argv) != 10:
        print("Usage: python script.py <species1 name> <exons1> <ir1> <species2 name> <exons2> <ir2> <species3 name> <exons3> <ir3>")
        sys.exit(1)

    species_data_list = []
    for i in range(3):  # I used 3 species
        base = i * 3 + 1
        species = sys.argv[base]
        exons = sys.argv[base + 1]
        ir = sys.argv[base + 2]
        species_data = analyze_species(exons, ir, species)
        species_data_list.append(species_data)

    plot_ir_events_by_exon_count(species_data_list)
